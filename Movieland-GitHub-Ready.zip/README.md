# Movieland

A simple Android movie-browser starter app.

## Build on GitHub

This project includes a GitHub Actions workflow. Upload the contents of this folder to the root of your GitHub repository. Then open **Actions**, select **Build Movieland APK**, and run the workflow.

The workflow downloads Gradle on the GitHub runner, builds the debug APK, and uploads the APK as an artifact.

The app is designed for legitimate movie metadata and legal viewing sources. It does not bypass subscriptions, DRM, or copyright restrictions.
