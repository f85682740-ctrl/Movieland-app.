package com.example.movieland;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    private LinearLayout root;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showHome();
    }

    private TextView text(String value, float size) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(Color.WHITE);
        v.setPadding(18, 14, 18, 14);
        return v;
    }

    private void showHome() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(16, 24, 16, 24);
        root.setBackgroundColor(Color.rgb(16, 18, 16));

        TextView title = text("MOVIELAND", 30);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView sub = text("Discover movies • New releases • Search", 15);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);

        EditText search = new EditText(this);
        search.setHint("Search movies");
        search.setHintTextColor(Color.GRAY);
        search.setTextColor(Color.WHITE);
        root.addView(search);

        String[] sections = {
            "🔥 New Releases",
            "🎬 Popular Movies",
            "⚡ Action",
            "😂 Comedy",
            "❤️ Drama",
            "✨ Animation"
        };

        for (String section : sections) {
            TextView card = text(section + "\nBrowse movie information and legal viewing options", 18);
            card.setBackgroundColor(Color.rgb(35, 38, 35));
            LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(-1, 120);
            p.setMargins(0, 10, 0, 0);
            root.addView(card, p);
        }

        TextView info = text(
            "\nThis is a free movie-browser starter.\n" +
            "Movie listings can be connected to a legitimate movie-data API.\n" +
            "It does not bypass subscriptions, DRM, or copyright restrictions.",
            14
        );
        root.addView(info);

        scroll.addView(root);
        setContentView(scroll);
    }
}
